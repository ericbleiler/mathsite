﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.OleDb;
using System.Data.Odbc;

namespace MathSite.Models
{
  
        public class DBConnection
        {
            private List<UserName> UserName = new List<UserName>();

        public void EnterUserName(string UserName, string Password)
        {


            string UserId = "UserId";
            aConnection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;
            Data Source=C:\Users\Eric\Desktop\MathSite\User.mdb;";

            aConnection.Open();

            OleDbCommand aCommand = aConnection.CreateCommand();

         


            string aSQL = "INSERT INTO UserName(UserID, UserName, Password)";
            aSQL = aSQL + "VALUES('" + UserId + "' + '" + UserName + "','" + Password + "')";
           


        }
        private OleDbConnection aConnection = new OleDbConnection();

            public List<UserName> GetUserName()
            {


                string aSQL = "SELECT ID, UserName FROM UserName;";

                aConnection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;
            Data Source=C:\Users\Eric\Desktop\MathSite\User.mdb;";

                aConnection.Open();

                OleDbCommand aCommand = aConnection.CreateCommand();

                aCommand.CommandText = aSQL;

                OleDbDataReader aReader = aCommand.ExecuteReader();

                // Read the data and store it in a list
                while (aReader.Read())
                {

                    string aName = (string)aReader["UserName"];

                    UserName aUserName = new UserName();

                    aUserName.Name = aName;


                    UserName.Add(aUserName);
                }

                return UserName;

            }

        public bool AddAddition(int num1, int num2, int userAnswer, int correctAnswer, int questionNum)
        {

         
                string aSql = "INSERT INTO Addition(num1, num2, UserAnswer, CorrectAnswer, Question)";
                aSql = aSql + "VALUES(" + num1 + "," + num2 + " , " + userAnswer + ", " + correctAnswer + ", " + questionNum + ")";

                aConnection.ConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;
               Data Source=C:\Users\Eric\Desktop\MathSite\User.mdb;";

                bool flag = false;

                aConnection.Open();

                OleDbCommand aCommand = aConnection.CreateCommand();

                aCommand.CommandText = aSql;

                aCommand.ExecuteNonQuery();


                flag = true;
                aConnection.Close();
            
            return flag;

        }
    }
    }
    