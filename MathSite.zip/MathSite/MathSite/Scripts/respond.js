var reset = document.getElementById("reset");
var answer = document.getElementById("userAnswer");
var enter = document.getElementById("enter");
var level = parseInt(document.getElementById('level').value, 10);
var output = document.getElementById("output");
var leftnum = document.getElementById("num1");
var rightnum = document.getElementById("num2");
var operator = document.getElementById("sign");
var submit = document.getElementById("submit");
var reset = document.getElementById("reset");
var userAnswer = document.getElementById("userAnswer");
var mathSigns = document.getElementsByName("operator");
var totalDiv = document.getElementById("total");
var numRightDiv = document.getElementById("numRight");
var count = document.getElementById("questionNum");
var solution, runningTotal = 0, tally = 0;
var correctAns;
var userAns;
var counter = 1;
var correct = false;
var resultArray1 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
var resultArray2 = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
var answerArray = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
var yourAnswerArray = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0];
var resultString = " ";
var num1, num2 = 0;

if (document.getElementById("submit").disabled == false) {
    answer.addEventListener("keypress", function (event) {

        if (event.keyCode == 13)
            submit.click();
          
           
            
    });
}


document.getElementById("popup1close").onkeydown = function (e) {
    if (e.keyCode == 13) {
        
    }
};




submit.addEventListener("click", solve, false);
reset.addEventListener("click", newEquation, false);
document.getElementsByTagName("fieldset")[0].addEventListener("click", init, false);

// Generate new numbers and math signs



function init() {
    for (var i = 0; i < mathSigns.length; i++) {
        if (mathSigns[i].checked) {
            chosenSign = mathSigns[i];
        }
        operator.textContent = chosenSign.nextElementSibling.textContent;

    
        do {
            if (level == 3) {
                num1 = Math.ceil(Math.random() * 100);
                num2 = Math.ceil(Math.random() * 100);

                if (num1 < 10) { num1 = 0; }
                if (operator.textContent == '*') {
                    if (num1 > 30) { num1 = 0; } if (num2 > 30) { num1 = 0; }
                }
            }
            else if (level == 2) {
                num1 = Math.ceil(Math.random() * 60);
                num2 = Math.ceil(Math.random() * 60);

                if (num1 < 10) { num1 = 0; }
                if (operator.textContent == '*') {
                    if (num1 > 20) { num1 = 0; } if (num2 > 20) { num1 = 0; }
                }
            } else if(level == 1){
                num1 = Math.ceil(Math.random() * 30);
                num2 = Math.ceil(Math.random() * 30);

                if (operator.textContent == '*') {
                    if (num1 > 10) { num1 = 0; } if (num2 > 10) { num1 = 0; }
                }
            }
            if (operator.textContent == '/') {
                
                if (num1 % num2 != 0) { num1 = 0; }
            }
         
            if (num2 == 1) { num1 = 0; }
            if (num1 == num2) { num1 = 0; }
            if (num1 < num2) { num1 = 0; }

        } while (num1 == 0);

        document.getElementById("num1").innerHTML = num1;
        document.getElementById("num2").innerHTML = num2;
       
  
        resultArray1[counter - 1] = num1;
        resultArray2[counter - 1] = num2;
        document.getElementById("count").innerHTML = "Question " + counter + " of 10";
        document.getElementById("questionNum").value = counter;

    }
    $(document).ready(function () {
        $(".popup-container").hide();
      
          
       
        $("#popup1close").click(function () {
            $("#popup1").fadeOut();
        });
    });
    // var pickedSign = mathSigns[Math.floor(Math.random() * mathSigns.length)]

    // Place random numbers in their
    // respective <span>s on the page
    correctAns = num1 + num2;
    if (counter > 1) {
        document.getElementById("number1").value += "," + num1;
        document.getElementById("number2").value += "," + num2;
        document.getElementById("correct").value += "," + correctAns;
        document.getElementById("user").value += "," + correctAns;
    } else {
        document.getElementById("number1").value += num1;
        document.getElementById("number2").value += num2;
        document.getElementById("correct").value += correctAns;
        document.getElementById("user").value += correctAns;
    }
    leftnum.value = num1;
    rightnum.value = num2;
   

    userAnswer.textContent = "";
    // Focus the keyboard on the answer field
    userAnswer.focus();

    if (submit.hasAttribute("disabled")) {
        submit.removeAttribute("disabled");
        submit.style.color = "white";
        submit.textContent = "Solve";
        userAnswer.value = "";
        userAnswer.style.backgroundColor = "#9C8AA5";
        userAnswer.style.color = "#0489B1";
        reset.setAttribute("disabled");
    }
    reset.setAttribute("disabled", "disabled");

    // Return an array containing the randomly generated items
    return numbers = [num1, num2, chosenSign.id];
}

function newEquation() {
    if (!submit.hasAttribute("disabled")) {
        solve();
    }
    submit.textContent = "Solve";
    submit.style.color = "white";
    tally++;
    userAnswer.style.backgroundColor = "white";
    userAnswer.style.color = "#0489B1";
    userAnswer.value = "";
    userAnswer.focus();
    submit.removeAttribute("disabled");
    init();
}

function increaseProgressWidth() {

    yourAnswerArray[counter] = userAnswer.value;
    if (counter < 10) { counter += 1; }
    if (numRightDiv.style.width != "0px") {
        var currentWidth = Number(numRightDiv.style.width.slice(0, 2));
        currentWidth += 10;
        numRightDiv.style.width = currentWidth + "%";
        if (numRightDiv.style.width == "100%") {
            //document.body.innerHTML += "<h1>Great job</h1><p>You solved 10 math problems!</p><a href='javascript:history.go(0);'>Again</a>";
           }
    } else {
        numRightDiv.style.width = "10%";
    }
    
}

// Display answer on page
function solve() {
    switch (operator.textContent) {
        case '+':
            correctAns = numbers[0] + numbers[1];
            break;
        case '-':
            correctAns = numbers[0] - numbers[1];
            break;
        case '*':
            correctAns = numbers[0] * numbers[1];
            break;
        case '/':
            correctAns = numbers[0] / numbers[1];
            break;
    }

    yourAnswerArray[counter - 1] = userAnswer.value;
    
    if (userAnswer.value == correctAns) {
        
        //userAnswer.style.backgroundColor = "white";
        userAnswer.style.color = "#0489B1";
        this.textContent = "Correct";
        this.style.color = "rebeccapurple";
        runningTotal++;
        correct = true;
        $("#popup1").fadeIn();
        document.getElementById("popuptext").innerHTML = "Your answer is correct";
       if (counter > 9) {
            resultstring = "<table align=left>";
       var n = 0;
            for (var i = 0; i < 10; i++) {
                answerArray[i] = resultArray1[i] + resultArray2[i];
                n++;
                intString1 += answerArray[i] + ',';
                intString2 += resultArray1[i] + ',';
                intString3 += resultArray2[i] + ',';
                intString4 += yourAnswerArray[i] + ',';
                resultString += "<tr><td>" + n + ": " + resultArray1[i] + " + " + resultArray2[i] + " =</td><td> " + answerArray[i] + "</td></tr>";
                resultString += "   <tr><td>Your answer: " + yourAnswerArray[i];

                if (answerArray[i] == yourAnswerArray[i]) {
                    resultString += "  </td><td>Correct Answer" + "</td></tr><br />";
                }
                else {
                    resultString += "  </td><td>Incorrect Answer" + "</td></tr><br />";
                }
                
            } resultString += "</table>";

        document.getElementById("popuptext").innerHTML = resultString;
           
            
        }

    } else {
        userAnswer.style.backgroundColor = "crimson";
        userAnswer.style.color = "white";
      
        this.textContent = "Wrong";
        this.style.color = "crimson";
        correct = false;
        $("#popup1").fadeIn(); 
        document.getElementById("popuptext").innerHTML = "Your answer is incorrect. <br />The correct answer is: " + correctAns;
        
    }
    increaseProgressWidth();
    submit.setAttribute("disabled", "disabled");
    reset.removeAttribute("disabled");
    return solution;
}

init();



var ww = document.body.clientWidth;

$(document).ready(function () {
    $(".nav li a").each(function () {
        if ($(this).next().length > 0) {
            $(this).addClass("parent");
        };
    })

    $(".toggleMenu").click(function (e) {
        e.preventDefault();
        $(this).toggleClass("active");
        $(".nav").toggle();
    });
    adjustMenu();
})

$(window).bind('resize orientationchange', function () {
    ww = document.body.clientWidth;
    adjustMenu();
});

var adjustMenu = function () {
    if (ww < 726) {
        $(".toggleMenu").css("display", "inline-block");
        if (!$(".toggleMenu").hasClass("active")) {
            $(".nav").hide();
            $("toggleMenu").attr('src', 'images/menu.jpg');
        } else {

            $("toggleMenu").attr('src', 'images/menu2.jpg');

            $(".nav").show();
        }
        $(".nav li").unbind('mouseenter mouseleave');
        $(".nav li a.parent").unbind('click').bind('click', function (e) {
            // must be attached to anchor element to prevent bubbling
            e.preventDefault();
            $(this).parent("li").toggleClass("hover");
        });
    }
    else if (ww >= 726) {
        $(".toggleMenu").css("display", "none");
        $(".nav").show();
        $(".nav li").removeClass("hover");
        $(".nav li a").unbind('click');
        $(".nav li").unbind('mouseenter mouseleave').bind('mouseenter mouseleave', function () {
            // must be attached to li so that mouseleave is not triggered when hover over submenu
            $(this).toggleClass('hover');
        });
    }
}










window.matchMedia = window.matchMedia || (function(doc, undefined){
  
  var bool,
      docElem  = doc.documentElement,
      refNode  = docElem.firstElementChild || docElem.firstChild,
      // fakeBody required for <FF4 when executed in <head>
      fakeBody = doc.createElement('body'),
      div      = doc.createElement('div');
  
  div.id = 'mq-test-1';
  div.style.cssText = "position:absolute;top:-100em";
  fakeBody.style.background = "none";
  fakeBody.appendChild(div);
  
  return function(q){
    
    div.innerHTML = '&shy;<style media="'+q+'"> #mq-test-1 { width: 42px; }</style>';
    
    docElem.insertBefore(fakeBody, refNode);
    bool = div.offsetWidth == 42;  
    docElem.removeChild(fakeBody);
    
    return { matches: bool, media: q };
  };
  
})(document);




/*! Respond.js v1.2.0: min/max-width media query polyfill. (c) Scott Jehl. MIT/GPLv2 Lic. j.mp/respondjs  */
(function( win ){
	//exposed namespace
	win.respond		= {};
	
	//define update even in native-mq-supporting browsers, to avoid errors
	respond.update	= function(){};
	
	//expose media query support flag for external use
	respond.mediaQueriesSupported	= win.matchMedia && win.matchMedia( "only all" ).matches;
	
	//if media queries are supported, exit here
	if( respond.mediaQueriesSupported ){ return; }
	
	//define vars
	var doc 			= win.document,
		docElem 		= doc.documentElement,
		mediastyles		= [],
		rules			= [],
		appendedEls 	= [],
		parsedSheets 	= {},
		resizeThrottle	= 30,
		head 			= doc.getElementsByTagName( "head" )[0] || docElem,
		base			= doc.getElementsByTagName( "base" )[0],
		links			= head.getElementsByTagName( "link" ),
		requestQueue	= [],
		
		//loop stylesheets, send text content to translate
		ripCSS			= function(){
			var sheets 	= links,
				sl 		= sheets.length,
				i		= 0,
				//vars for loop:
				sheet, href, media, isCSS;

			for( ; i < sl; i++ ){
				sheet	= sheets[ i ],
				href	= sheet.href,
				media	= sheet.media,
				isCSS	= sheet.rel && sheet.rel.toLowerCase() === "stylesheet";

				//only links plz and prevent re-parsing
				if( !!href && isCSS && !parsedSheets[ href ] ){
					// selectivizr exposes css through the rawCssText expando
					if (sheet.styleSheet && sheet.styleSheet.rawCssText) {
						translate( sheet.styleSheet.rawCssText, href, media );
						parsedSheets[ href ] = true;
					} else {
						if( (!/^([a-zA-Z:]*\/\/)/.test( href ) && !base)
							|| href.replace( RegExp.$1, "" ).split( "/" )[0] === win.location.host ){
							requestQueue.push( {
								href: href,
								media: media
							} );
						}
					}
				}
			}
			makeRequests();
		},
		
		//recurse through request queue, get css text
		makeRequests	= function(){
			if( requestQueue.length ){
				var thisRequest = requestQueue.shift();
				
				ajax( thisRequest.href, function( styles ){
					translate( styles, thisRequest.href, thisRequest.media );
					parsedSheets[ thisRequest.href ] = true;
					makeRequests();
				} );
			}
		},
		
		//find media blocks in css text, convert to style blocks
		translate			= function( styles, href, media ){
			var qs			= styles.match(  /@media[^\{]+\{([^\{\}]*\{[^\}\{]*\})+/gi ),
				ql			= qs && qs.length || 0,
				//try to get CSS path
				href		= href.substring( 0, href.lastIndexOf( "/" )),
				repUrls		= function( css ){
					return css.replace( /(url\()['"]?([^\/\)'"][^:\)'"]+)['"]?(\))/g, "$1" + href + "$2$3" );
				},
				useMedia	= !ql && media,
				//vars used in loop
				i			= 0,
				j, fullq, thisq, eachq, eql;

			//if path exists, tack on trailing slash
			if( href.length ){ href += "/"; }	
				
			//if no internal queries exist, but media attr does, use that	
			//note: this currently lacks support for situations where a media attr is specified on a link AND
				//its associated stylesheet has internal CSS media queries.
				//In those cases, the media attribute will currently be ignored.
			if( useMedia ){
				ql = 1;
			}
			

			for( ; i < ql; i++ ){
				j	= 0;
				
				//media attr
				if( useMedia ){
					fullq = media;
					rules.push( repUrls( styles ) );
				}
				//parse for styles
				else{
					fullq	= qs[ i ].match( /@media *([^\{]+)\{([\S\s]+?)$/ ) && RegExp.$1;
					rules.push( RegExp.$2 && repUrls( RegExp.$2 ) );
				}
				
				eachq	= fullq.split( "," );
				eql		= eachq.length;
					
				for( ; j < eql; j++ ){
					thisq	= eachq[ j ];
					mediastyles.push( { 
						media	: thisq.split( "(" )[ 0 ].match( /(only\s+)?([a-zA-Z]+)\s?/ ) && RegExp.$2 || "all",
						rules	: rules.length - 1,
						hasquery: thisq.indexOf("(") > -1,
						minw	: thisq.match( /\(min\-width:[\s]*([\s]*[0-9\.]+)(px|em)[\s]*\)/ ) && parseFloat( RegExp.$1 ) + ( RegExp.$2 || "" ), 
						maxw	: thisq.match( /\(max\-width:[\s]*([\s]*[0-9\.]+)(px|em)[\s]*\)/ ) && parseFloat( RegExp.$1 ) + ( RegExp.$2 || "" )
					} );
				}	
			}

			applyMedia();
		},
        	
		lastCall,
		
		resizeDefer,
		
		// returns the value of 1em in pixels
		getEmValue		= function() {
			var ret,
				div = doc.createElement('div'),
				body = doc.body,
				fakeUsed = false;
									
			div.style.cssText = "position:absolute;font-size:1em;width:1em";
					
			if( !body ){
				body = fakeUsed = doc.createElement( "body" );
				body.style.background = "none";
			}
					
			body.appendChild( div );
								
			docElem.insertBefore( body, docElem.firstChild );
								
			ret = div.offsetWidth;
								
			if( fakeUsed ){
				docElem.removeChild( body );
			}
			else {
				body.removeChild( div );
			}
			
			//also update eminpx before returning
			ret = eminpx = parseFloat(ret);
								
			return ret;
		},
		
		//cached container for 1em value, populated the first time it's needed 
		eminpx,
		
		//enable/disable styles
		applyMedia			= function( fromResize ){
			var name		= "clientWidth",
				docElemProp	= docElem[ name ],
				currWidth 	= doc.compatMode === "CSS1Compat" && docElemProp || doc.body[ name ] || docElemProp,
				styleBlocks	= {},
				lastLink	= links[ links.length-1 ],
				now 		= (new Date()).getTime();

			//throttle resize calls	
			if( fromResize && lastCall && now - lastCall < resizeThrottle ){
				clearTimeout( resizeDefer );
				resizeDefer = setTimeout( applyMedia, resizeThrottle );
				return;
			}
			else {
				lastCall	= now;
			}
										
			for( var i in mediastyles ){
				var thisstyle = mediastyles[ i ],
					min = thisstyle.minw,
					max = thisstyle.maxw,
					minnull = min === null,
					maxnull = max === null,
					em = "em";
				
				if( !!min ){
					min = parseFloat( min ) * ( min.indexOf( em ) > -1 ? ( eminpx || getEmValue() ) : 1 );
				}
				if( !!max ){
					max = parseFloat( max ) * ( max.indexOf( em ) > -1 ? ( eminpx || getEmValue() ) : 1 );
				}
				
				// if there's no media query at all (the () part), or min or max is not null, and if either is present, they're true
				if( !thisstyle.hasquery || ( !minnull || !maxnull ) && ( minnull || currWidth >= min ) && ( maxnull || currWidth <= max ) ){
						if( !styleBlocks[ thisstyle.media ] ){
							styleBlocks[ thisstyle.media ] = [];
						}
						styleBlocks[ thisstyle.media ].push( rules[ thisstyle.rules ] );
				}
			}
			
			//remove any existing respond style element(s)
			for( var i in appendedEls ){
				if( appendedEls[ i ] && appendedEls[ i ].parentNode === head ){
					head.removeChild( appendedEls[ i ] );
				}
			}
			
			//inject active styles, grouped by media type
			for( var i in styleBlocks ){
				var ss		= doc.createElement( "style" ),
					css		= styleBlocks[ i ].join( "\n" );
				
				ss.type = "text/css";	
				ss.media	= i;
				
				//originally, ss was appended to a documentFragment and sheets were appended in bulk.
				//this caused crashes in IE in a number of circumstances, such as when the HTML element had a bg image set, so appending beforehand seems best. Thanks to @dvelyk for the initial research on this one!
				head.insertBefore( ss, lastLink.nextSibling );
				
				if ( ss.styleSheet ){ 
		        	ss.styleSheet.cssText = css;
		        } 
		        else {
					ss.appendChild( doc.createTextNode( css ) );
		        }
		        
				//push to appendedEls to track for later removal
				appendedEls.push( ss );
			}
		},
		//tweaked Ajax functions from Quirksmode
		ajax = function( url, callback ) {
			var req = xmlHttp();
			if (!req){
				return;
			}	
			req.open( "GET", url, true );
			req.onreadystatechange = function () {
				if ( req.readyState != 4 || req.status != 200 && req.status != 304 ){
					return;
				}
				callback( req.responseText );
			}
			if ( req.readyState == 4 ){
				return;
			}
			req.send( null );
		},
		//define ajax obj 
		xmlHttp = (function() {
			var xmlhttpmethod = false;	
			try {
				xmlhttpmethod = new XMLHttpRequest();
			}
			catch( e ){
				xmlhttpmethod = new ActiveXObject( "Microsoft.XMLHTTP" );
			}
			return function(){
				return xmlhttpmethod;
			};
		})();
	
	//translate CSS
	ripCSS();
	
	//expose update for re-running respond later on
	respond.update = ripCSS;
	
	//adjust on resize
	function callMedia(){
		applyMedia( true );
	}
	if( win.addEventListener ){
		win.addEventListener( "resize", callMedia, false );
	}
	else if( win.attachEvent ){
		win.attachEvent( "onresize", callMedia );
	}
})(this);
