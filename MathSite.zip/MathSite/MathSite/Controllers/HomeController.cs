﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MathSite.Models;

namespace MathSite.Controllers
{
    public class HomeController : Controller
    {
       
       
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult AddAddition(string num1, string num2, string user, string correct, int questionNum )
        {
            string[] num1Array = num1.Split(',');
            string[] num2Array = num2.Split(',');
            string[] userArray = user.Split(',');
            string[] correctArray = correct.Split(',');
            int[] number1Array;
            int[] number2Array;
            int[] userAnswerArray;
            int[] correctAnswerArray;
            number1Array = new int[10];
            number2Array = new int[10];
            userAnswerArray = new int[10];
            correctAnswerArray = new int[10];
            int question = 0;
            
            for (int i = 0; i < questionNum; i++)
            {
                number1Array[i] = Int32.Parse(num1Array[i]);
                number2Array[i] = Int32.Parse(num2Array[i]);
                userAnswerArray[i] = Int32.Parse(userArray[i]);
                correctAnswerArray[i] = Int32.Parse(correctArray[i]);

                ViewBag.num1 = num1;
                ViewBag.num2 = num2;
                ViewBag.user = user;
                ViewBag.correct = correct;
                ViewBag.counter = questionNum;
                question++;
                DBConnection aConnection = new DBConnection();
                aConnection.AddAddition(number1Array[i], number2Array[i], userAnswerArray[i], correctAnswerArray[i], question);


                string aSql = "INSERT INTO Addition(num1, num2, UserAnswer, CorrectAnswer, Question)";
                aSql = aSql + "VALUES(" + number1Array[i] + "," + number2Array[i] + " , " + userAnswerArray[i] + ", " + correctAnswerArray[i] + ", " + question + ")";

                ViewBag.Sql = aSql;
            }
            return View();
        }
        public ActionResult Addition1()
        {
           return View();
        }
        public ActionResult Addition2()
        {
            return View();
        }
        public ActionResult Addition3()
        {
            return View();
        }
        public ActionResult Subtraction1()
        {
            return View();
        }
        public ActionResult Subtraction2()
        {
            return View();
        }
        public ActionResult Subtraction3()
        {
            return View();
        }
        public ActionResult Multiplication1()
        {
            return View();
        }
        public ActionResult Multiplication2()
        {
            return View();
        }
        public ActionResult Multiplication3()
        {
            return View();
        }
        public ActionResult Division1()
        {
            return View();
        }
        public ActionResult Division2()
        {
            return View();
        }
        public ActionResult Division3()
        {
            return View();
        }

        public ActionResult Result()
        {
            return View();
        }
        public ActionResult AddUser(string UserName, string Password)
        {
            
            ViewBag.UserName = UserName;
            ViewBag.Password = Password;
            DBConnection DB = new DBConnection();
            DB.EnterUserName(UserName, Password);
            string aSQL = "INSERT INTO User(UserName, Password)";
            aSQL = aSQL + "VALUES('" + UserName + "','" + Password + "')";
            ViewBag.Sql = aSQL;
            return View();

        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult UserName()
        {
            DBConnection aConnection = new DBConnection();
            List<UserName> aUserName = null;
            aUserName = aConnection.GetUserName();
            ViewBag.UserName = aUserName;

            return View();
        }
    }
}